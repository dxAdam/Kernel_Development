All functions seem to be working as intended. 

We did not get any occasional or rare test fails when running the provided driver or a modified driver file that contained additional tests.

We do not detect any memory leaks in our Lock-Free Queue when checked with Valgrind.

locking.h has not been modified.

Answers to project questions are in the comments where the question is asked.
